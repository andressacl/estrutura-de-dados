#ifndef AVL_H 
#define AVL_H

#include "../Util/Util.h"
#include "../Game/Game.h"

typedef struct node_st Node;
typedef struct avl_st Avl;

Avl *avl_create();

int height(Node *root);

boolean avl_insert(Avl *avl, Game *game);

Node *right_rotation(Node *a);
Node *left_rotation(Node *a);
Node *left_right_rotation(Node *a);
Node *right_left_rotation(Node *a);

Game *game_search(Node *raiz, Game *game);

void avl_pre_order(Avl *avl);
void avl_in_order(Avl *avl);
void avl_post_order(Avl *avl);

void avl_delete(Avl **avl_ref); 

#endif