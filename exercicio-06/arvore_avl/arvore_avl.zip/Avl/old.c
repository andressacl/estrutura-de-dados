

// static Node *avl_insertion(Node *root, Jogo *jogo) {
//   if (!root) return node_create(jogo);
//   if (jogo->anode_lan < root->jogo){
//     root->esquerda = avl_insertion(root->esquerda,*jogo);
//     if ((height(root->esquerda)-height(root->direita))==2)
//       if (jogo->anode_lan < root->esquerda->jogo) root = rotacao_direita(root);
//     else root = rotacao_esquerda_direita(root);
//   }
//   else
//     if (jogo->anode_lan > root->jogo){
//       root->direita = insere(root->direita,jogo);
//       if (height(root->direita)-height(root->esquerda==2))
//         if  (jogo->anode_lan > root->direita->jogo)
//           root = rotacao_esquerda(root);
//         else
//           root = rotacao_direita_esquerda(root);
//       }
//   root->altura = max(height(root->esquerda),height(root->direita)) +1;

//   return root
       
//     }
// }

// static Node* avl_insertion(Node *root, Jogo *jogo) {
//   if (!root) return NULL;
//   if (jogo->anode_lan < root->jogo){
//     //remoçao nó folha
//     if (root->esquerda==NULL && root->direita==NULL){
//       free(root);
//       return NULL; 
//     }
//     else{
//       //remoçao nó com 2 filhos
//       if (root->esquerda != NULL && root->direita != NULL){
//       }
//     }
//     //(...) remocao nó com 1 filho

    
//   root->altura = max(height(root->esquerda),height(root->direita)) +1;

//   return root
      
//     }
// }

// static void pre_order_recursion(Node *root) {
    
// }

// void avl_print_pre_order(Avl *avl){
	
// }


// Jogo *get_jogo(Node *node){
// 	return node->jogo;
// }

// Jogo *jogo_search(Node *root, Jogo *jogo){
// 	if (root == NULL) return NULL;
// 	if (jogo->anode_lan == root->jogo) return root->jogo
//     return root->jogo;
//   if (jogo->anode_lan < root->jogo) return jogo_search(root->direita,jogo->anode_lan);
// 	return jogo_search(root->esquerda,jogo->anode_lan);
// }

// void avl_delete(Avl **avl_ref) {
//   Avl *avl = *avl_ref;
//   free(*arvore);
//   *arvore = NULL;
// }