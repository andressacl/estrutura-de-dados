
// static Node* avl_insertion(Node *root, Jogo *jogo) {
//   if (!root) return NULL;
//   if (jogo->anode_lan < root->jogo){
//     //remoçao nó folha
//     if (root->esquerda==NULL && root->direita==NULL){
//       free(root);
//       return NULL; 
//     }
//     else{
//       //remoçao nó com 2 filhos
//       if (root->esquerda != NULL && root->direita != NULL){
//       }
//     }
//     //(...) remocao nó com 1 filho

    
//   root->altura = max(height(root->esquerda),height(root->direita)) +1;

//   return root
      
//     }
// }


// Jogo *jogo_search(Node *root, Jogo *jogo){
// 	if (root == NULL) return NULL;
// 	if (jogo->anode_lan == root->jogo) return root->jogo
//     return root->jogo;
//   if (jogo->anode_lan < root->jogo) return jogo_search(root->direita,jogo->anode_lan);
// 	return jogo_search(root->esquerda,jogo->anode_lan);
// }

