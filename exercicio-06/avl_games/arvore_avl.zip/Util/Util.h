#ifndef UTIL_H
#define UTIL_H

#define TRUE 1
#define FALSE 0
typedef int boolean;

#define max(a, b) ((a > b) ? a : b)

void boolean_print(boolean bool);

char *readLine();

// int max(int a, int b);

#endif //UTIL_H
